import { useEffect, useRef, useState } from 'react'
import { Toolbar } from '@/components/editor/Toolbar'
import { Sidebar } from '@/components/editor/Sidebar'
import { PropertiesPanel } from '@/components/editor/PropertiesPanel'
import { Scene } from '@/components/editor/Scene'
import { toast, ToastViewport } from '@/components/ui/Toast'
import { useEditorStore, readAutosave, clearAutosave } from '@/store/editor'
import '@/assets/styles/editor.css'

export default function Editor() {
  const undo = useEditorStore((s) => s.undo)
  const redo = useEditorStore((s) => s.redo)
  const selectObject = useEditorStore((s) => s.selectObject)
  const setTransformMode = useEditorStore((s) => s.setTransformMode)
  const removeObject = useEditorStore((s) => s.removeObject)
  const objects = useEditorStore((s) => s.objects)
  const selectedId = useEditorStore((s) => s.selectedId)
  const replaceScene = useEditorStore((s) => s.replaceScene)

  const [restorePrompt, setRestorePrompt] = useState(false)
  const restoredRef = useRef(false)

  /* ---------- 自动恢复提示（首次挂载） ---------- */
  useEffect(() => {
    if (restoredRef.current) return
    restoredRef.current = true
    const snap = readAutosave()
    if (snap && snap.objects.length > 0) {
      setRestorePrompt(true)
    }
  }, [])

  const handleRestoreYes = () => {
    const snap = readAutosave()
    if (snap) replaceScene(snap.objects)
    clearAutosave()
    setRestorePrompt(false)
  }
  const handleRestoreNo = () => {
    clearAutosave()
    setRestorePrompt(false)
  }

  /* ---------- 全局快捷键 ---------- */
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // 输入框内的按键不拦截（除 Ctrl+Z/Y）
      const typing = isTyping(e.target)

      // Ctrl+Z 撤销
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault()
        undo()
        return
      }
      // Ctrl+Y / Ctrl+Shift+Z 重做
      if (
        ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') ||
        ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'z')
      ) {
        e.preventDefault()
        redo()
        return
      }
      if (typing) return

      // Delete / Backspace 删除选中
      if (e.key === 'Delete' || e.key === 'Backspace') {
        const id = useEditorStore.getState().selectedId
        if (id) {
          e.preventDefault()
          removeObject(id)
        }
        return
      }
      // Esc 取消选中
      if (e.key === 'Escape') {
        selectObject(null)
        return
      }
      // W / E / R 切换 Gizmo 模式
      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        const k = e.key.toLowerCase()
        if (k === 'w') {
          setTransformMode('translate')
          if (!useEditorStore.getState().selectedId) {
            toast.info('已切换平移模式 · 请先在场景中选中一个对象')
          }
        } else if (k === 'e') {
          setTransformMode('rotate')
          if (!useEditorStore.getState().selectedId) {
            toast.info('已切换旋转模式 · 请先在场景中选中一个对象')
          }
        } else if (k === 'r') {
          setTransformMode('scale')
          if (!useEditorStore.getState().selectedId) {
            toast.info('已切换缩放模式 · 请先在场景中选中一个对象')
          }
        }
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [undo, redo, selectObject, setTransformMode, removeObject])

  /* ---------- 未保存离开警告 ---------- */
  useEffect(() => {
    const beforeUnload = (e: BeforeUnloadEvent) => {
      if (useEditorStore.getState().historyIndex > 0) {
        e.preventDefault()
        e.returnValue = ''
      }
    }
    window.addEventListener('beforeunload', beforeUnload)
    return () => window.removeEventListener('beforeunload', beforeUnload)
  }, [])

  return (
    <div className="editor-layout">
      <Toolbar />
      <div className="editor-main">
        <Sidebar />
        <div className="editor-canvas">
          <Scene />
          <StatusBar objectCount={objects.length} selectedId={selectedId} />
        </div>
        <PropertiesPanel />
      </div>

      {restorePrompt && (
        <div className="modal-backdrop">
          <div className="modal-card">
            <div className="modal-title">检测到上次未保存的编辑</div>
            <div className="modal-body">
              要不要恢复上次的场景？<br />
              <small style={{ opacity: 0.7 }}>
                选择「不恢复」会清除自动保存，并打开默认场景。
              </small>
            </div>
            <div className="modal-actions">
              <button className="modal-btn primary" onClick={handleRestoreYes}>
                恢复
              </button>
              <button className="modal-btn" onClick={handleRestoreNo}>
                不恢复
              </button>
            </div>
          </div>
        </div>
      )}

      <ToastViewport />
    </div>
  )
}

/* ==================== 工具函数 ==================== */

function isTyping(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false
  const tag = target.tagName
  return tag === 'INPUT' || tag === 'TEXTAREA' || target.isContentEditable
}

/* ==================== StatusBar ==================== */

function StatusBar({
  objectCount,
  selectedId,
}: {
  objectCount: number
  selectedId: string | null
}) {
  const selectedName = useEditorStore(
    (s) => s.objects.find((o) => o.id === selectedId)?.name ?? '无',
  )

  return (
    <div className="status-bar">
      <span>对象数: {objectCount}</span>
      <span className="status-sep">|</span>
      <span>选中: {selectedId ? selectedName : '无'}</span>
      <span className="status-sep">|</span>
      <span className="status-hint">
        模式热键 W/E/R · Ctrl+Z 撤销 · Delete 删除 · Esc 取消选中
      </span>
    </div>
  )
}
