import { create } from 'zustand'
import type { Vector3Tuple } from 'three'
import type { HistoryEntry, PrimitiveType, SceneObject, TransformMode } from '@/types/editor'

/* ==================== 工具 ==================== */

const genId = () => `obj_${Math.random().toString(36).slice(2, 10)}`

const cloneObjects = (objects: SceneObject[]): SceneObject[] =>
  objects.map((o) => ({
    ...o,
    position: [...o.position] as Vector3Tuple,
    rotation: [...o.rotation] as Vector3Tuple,
    scale: [...o.scale] as Vector3Tuple,
  }))

/** 将新快照推入历史，截断 redo 分支，限制长度 50 */
function pushHistory(
  history: HistoryEntry[],
  index: number,
  objects: SceneObject[],
  selectedId: string | null,
): HistoryEntry[] {
  const truncated = history.slice(0, index + 1)
  truncated.push({ objects: cloneObjects(objects), selectedId })
  if (truncated.length > 50) truncated.shift()
  return truncated
}

const AUTOSAVE_KEY = 'editor.autosave'

function writeAutosave(objects: SceneObject[], selectedId: string | null) {
  try {
    sessionStorage.setItem(
      AUTOSAVE_KEY,
      JSON.stringify({ objects, selectedId, savedAt: Date.now() }),
    )
  } catch {
    /* ignore quota errors */
  }
}

export interface AutosaveSnapshot {
  objects: SceneObject[]
  selectedId: string | null
  savedAt: number
}

export function readAutosave(): AutosaveSnapshot | null {
  try {
    const raw = sessionStorage.getItem(AUTOSAVE_KEY)
    if (!raw) return null
    return JSON.parse(raw) as AutosaveSnapshot
  } catch {
    return null
  }
}

export function clearAutosave() {
  try {
    sessionStorage.removeItem(AUTOSAVE_KEY)
  } catch {
    /* ignore */
  }
}

/* ==================== 默认值 ==================== */

export const DEFAULT_COLORS: Record<PrimitiveType, string> = {
  box: '#6366f1',
  sphere: '#f59e0b',
  cylinder: '#10b981',
  cone: '#ef4444',
  torus: '#8b5cf6',
  tetrahedron: '#ec4899',
  plane: '#64748b',
}

export const DEFAULT_NAMES: Record<PrimitiveType, string> = {
  box: '长方体',
  sphere: '球体',
  cylinder: '圆柱',
  cone: '圆锥',
  torus: '圆环',
  tetrahedron: '四面体',
  plane: '平面',
}

export const DEFAULT_OBJECTS: SceneObject[] = [
  {
    id: genId(),
    name: '地板',
    type: 'plane',
    position: [0, 0, 0],
    rotation: [-Math.PI / 2, 0, 0],
    scale: [20, 20, 1],
    color: '#475569',
    visible: true,
  },
  {
    id: genId(),
    name: '示例方块',
    type: 'box',
    position: [0, 1, 0],
    rotation: [0, 0, 0],
    scale: [1, 1, 1],
    color: '#6366f1',
    visible: true,
  },
]

/* ==================== Store ==================== */

interface EditorState {
  objects: SceneObject[]
  selectedId: string | null
  transformMode: TransformMode
  history: HistoryEntry[]
  historyIndex: number

  // 瞬时更新（不产生历史，用于 Gizmo 逐帧同步、属性面板 input 事件）
  updateObject: (id: string, patch: Partial<SceneObject>) => void

  // 产生历史的操作
  addObject: (type: PrimitiveType, position?: Vector3Tuple) => void
  removeObject: (id: string) => void
  duplicateObject: (id: string) => void
  commitObjectUpdate: (id: string, patch: Partial<SceneObject>) => void
  toggleVisible: (id: string) => void
  clearScene: () => void

  // UI 选择 / 工具
  selectObject: (id: string | null) => void
  setTransformMode: (mode: TransformMode) => void

  // 历史导航
  undo: () => void
  redo: () => void

  // 会话级操作（不产生历史 / 重置历史）
  replaceScene: (objects: SceneObject[]) => void
  resetToDefault: () => void
}

const makeInitialHistory = (objects: SceneObject[]): HistoryEntry[] => [
  { objects: cloneObjects(objects), selectedId: null },
]

export const useEditorStore = create<EditorState>((set, get) => ({
  objects: DEFAULT_OBJECTS,
  selectedId: null,
  transformMode: 'translate',
  history: makeInitialHistory(DEFAULT_OBJECTS),
  historyIndex: 0,

  /* ---------- 瞬时更新（无历史） ---------- */
  updateObject: (id, patch) => {
    set((s) => ({
      objects: s.objects.map((o) => (o.id === id ? { ...o, ...patch } : o)),
    }))
  },

  /* ---------- 产生历史的写入 ---------- */
  addObject: (type, position) => {
    const obj: SceneObject = {
      id: genId(),
      name: `${DEFAULT_NAMES[type]} ${get().objects.filter((o) => o.type === type).length + 1}`,
      type,
      position: position ?? [0, type === 'plane' ? 0.01 : 1, 0],
      rotation: [0, 0, 0],
      scale: [1, 1, 1],
      color: DEFAULT_COLORS[type],
      visible: true,
    }
    set((s) => {
      const newObjects = [...s.objects, obj]
      const history = pushHistory(s.history, s.historyIndex, newObjects, obj.id)
      writeAutosave(newObjects, obj.id)
      return {
        objects: newObjects,
        selectedId: obj.id,
        history,
        historyIndex: s.historyIndex + 1,
      }
    })
  },

  removeObject: (id) => {
    set((s) => {
      const newObjects = s.objects.filter((o) => o.id !== id)
      const newSelected = s.selectedId === id ? null : s.selectedId
      const history = pushHistory(s.history, s.historyIndex, newObjects, newSelected)
      writeAutosave(newObjects, newSelected)
      return {
        objects: newObjects,
        selectedId: newSelected,
        history,
        historyIndex: s.historyIndex + 1,
      }
    })
  },

  duplicateObject: (id) => {
    const original = get().objects.find((o) => o.id === id)
    if (!original) return
    const copy: SceneObject = {
      ...original,
      id: genId(),
      name: `${original.name} 副本`,
      position: [original.position[0] + 1, original.position[1], original.position[2] + 1],
    }
    set((s) => {
      const newObjects = [...s.objects, copy]
      const history = pushHistory(s.history, s.historyIndex, newObjects, copy.id)
      writeAutosave(newObjects, copy.id)
      return {
        objects: newObjects,
        selectedId: copy.id,
        history,
        historyIndex: s.historyIndex + 1,
      }
    })
  },

  /** 属性面板 blur / 回车 时调用，把 patch 作为一次完整提交记入历史 */
  commitObjectUpdate: (id, patch) => {
    set((s) => {
      const newObjects = s.objects.map((o) => (o.id === id ? { ...o, ...patch } : o))
      const history = pushHistory(s.history, s.historyIndex, newObjects, s.selectedId)
      writeAutosave(newObjects, s.selectedId)
      return {
        objects: newObjects,
        history,
        historyIndex: s.historyIndex + 1,
      }
    })
  },

  toggleVisible: (id) => {
    set((s) => {
      const newObjects = s.objects.map((o) =>
        o.id === id ? { ...o, visible: !o.visible } : o,
      )
      const history = pushHistory(s.history, s.historyIndex, newObjects, s.selectedId)
      writeAutosave(newObjects, s.selectedId)
      return {
        objects: newObjects,
        history,
        historyIndex: s.historyIndex + 1,
      }
    })
  },

  clearScene: () => {
    set((s) => {
      const newObjects: SceneObject[] = []
      const history = pushHistory(s.history, s.historyIndex, newObjects, null)
      writeAutosave(newObjects, null)
      return {
        objects: newObjects,
        selectedId: null,
        history,
        historyIndex: s.historyIndex + 1,
      }
    })
  },

  /* ---------- UI ---------- */
  selectObject: (id) => set({ selectedId: id }),
  setTransformMode: (mode) => set({ transformMode: mode }),

  /* ---------- 历史导航 ---------- */
  undo: () => {
    const { historyIndex, history } = get()
    if (historyIndex <= 0) return
    const prev = history[historyIndex - 1]
    set({
      objects: cloneObjects(prev.objects),
      selectedId: prev.selectedId,
      historyIndex: historyIndex - 1,
    })
  },

  redo: () => {
    const { historyIndex, history } = get()
    if (historyIndex >= history.length - 1) return
    const next = history[historyIndex + 1]
    set({
      objects: cloneObjects(next.objects),
      selectedId: next.selectedId,
      historyIndex: historyIndex + 1,
    })
  },

  /* ---------- 会话级 ---------- */
  /** 导入 JSON 后整个场景被替换，历史清空（全新会话） */
  replaceScene: (objects) => {
    const fresh = cloneObjects(objects)
    writeAutosave(fresh, null)
    set({
      objects: fresh,
      selectedId: null,
      history: makeInitialHistory(fresh),
      historyIndex: 0,
    })
  },

  resetToDefault: () => {
    const fresh = cloneObjects(DEFAULT_OBJECTS)
    writeAutosave(fresh, null)
    set({
      objects: fresh,
      selectedId: null,
      transformMode: 'translate',
      history: makeInitialHistory(fresh),
      historyIndex: 0,
    })
  },
}))
