import type { Vector3Tuple } from 'three'

/** 支持的预设几何体类型 */
export type PrimitiveType = 'box' | 'sphere' | 'cylinder' | 'cone' | 'torus' | 'tetrahedron' | 'plane'

/** 3D 对象在编辑器中的数据模型 */
export interface SceneObject {
  id: string
  name: string
  type: PrimitiveType
  position: Vector3Tuple
  rotation: Vector3Tuple
  scale: Vector3Tuple
  color: string
  visible: boolean
}

/** 对象操作历史记录（用于撤销/重做） */
export interface HistoryEntry {
  objects: SceneObject[]
  selectedId: string | null
}

/** 变换模式 */
export type TransformMode = 'translate' | 'rotate' | 'scale'
