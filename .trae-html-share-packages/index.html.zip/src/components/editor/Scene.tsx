import { Canvas, useThree } from '@react-three/fiber'
import { OrbitControls, Sky, Grid, TransformControls, ContactShadows } from '@react-three/drei'
import { useEffect, useRef, useState } from 'react'
import * as THREE from 'three'
import { useEditorStore } from '@/store/editor'
import { SceneMesh } from './SceneMesh'
import { getMesh } from './meshRegistry'

export function Scene() {
  return (
    <Canvas
      shadows
      camera={{ position: [8, 8, 12], fov: 50 }}
      onPointerMissed={() => useEditorStore.getState().selectObject(null)}
      gl={{ antialias: true }}
    >
      {/* 程序化天空 */}
      <Sky sunPosition={[100, 20, 100]} turbidity={8} rayleigh={0.5} />

      {/* 光照 */}
      <ambientLight intensity={0.4} />
      <directionalLight
        position={[10, 20, 10]}
        intensity={1.2}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-left={-30}
        shadow-camera-right={30}
        shadow-camera-top={30}
        shadow-camera-bottom={-30}
      />

      {/* 地面网格 */}
      <Grid
        position={[0, 0.01, 0]}
        args={[40, 40]}
        cellSize={1}
        cellThickness={0.5}
        cellColor="#6b7280"
        sectionSize={5}
        sectionThickness={1}
        sectionColor="#374151"
        fadeDistance={40}
        fadeStrength={1}
        infiniteGrid
      />

      {/* 软阴影 */}
      <ContactShadows position={[0, 0.02, 0]} opacity={0.4} scale={30} blur={2} far={10} />

      {/* 场景对象 */}
      <SceneObjects />

      {/* 变换控制器 */}
      <TransformController />

      {/* 轨道控制 */}
      <OrbitControls
        makeDefault
        minDistance={3}
        maxDistance={60}
        maxPolarAngle={Math.PI / 2 - 0.05}
        enableDamping
        dampingFactor={0.08}
      />
    </Canvas>
  )
}

function SceneObjects() {
  const objects = useEditorStore((s) => s.objects)
  const selectedId = useEditorStore((s) => s.selectedId)
  const selectObject = useEditorStore((s) => s.selectObject)

  return (
    <group>
      {objects.map((o) =>
        o.visible ? (
          <SceneMesh
            key={o.id}
            id={o.id}
            type={o.type}
            color={o.color}
            selected={o.id === selectedId}
            onClick={selectObject}
          />
        ) : null,
      )}
    </group>
  )
}

/**
 * TransformControls：
 * - onObjectChange 只做瞬时同步（更新 Zustand 数据让属性面板实时刷新）
 * - onMouseUp 时再 commitObjectUpdate 产生一次历史快照（PRD 4.5 的拖拽粒度）
 */
function TransformController() {
  const selectedId = useEditorStore((s) => s.selectedId)
  const mode = useEditorStore((s) => s.transformMode)
  const updateObject = useEditorStore((s) => s.updateObject)
  const commitObjectUpdate = useEditorStore((s) => s.commitObjectUpdate)
  const events = useThree((s) => s.events)

  // 用 state 而非 ref：拿到 mesh 后必须触发 re-render 才能把 object 传给 <TransformControls>
  const [attachedObject, setAttachedObject] = useState<THREE.Object3D | null>(null)
  // 拖拽中 flag：避免 onMouseUp 没经过 onMouseDown 时误 commit
  const dragging = useRef(false)
  // 记住拖拽前 events.enabled 的状态，确保恢复正确
  const prevEventsEnabled = useRef(true)

  // 当选中 ID 变化时，从 registry 获取 THREE 对象（R3F 需要一帧挂载 mesh）
  useEffect(() => {
    dragging.current = false
    if (!selectedId) {
      setAttachedObject(null)
      return
    }
    const id = requestAnimationFrame(() => {
      const mesh = getMesh(selectedId)
      setAttachedObject(mesh ?? null)
    })
    return () => cancelAnimationFrame(id)
  }, [selectedId])

  if (!selectedId || !attachedObject) return null

  return (
    <TransformControls
      object={attachedObject}
      mode={mode}
      makeDefault
      onMouseDown={() => {
        dragging.current = true
        // 暂停 R3F 合成事件系统：TransformControls 激活时阻止 R3F raycaster 误命中其他 mesh
        // 否则 Gizmo 拖拽过程中 R3F 仍会跑 raycaster，把事件派发给射线穿透方向上的地板
        prevEventsEnabled.current = events.enabled
        events.enabled = false
      }}
      onObjectChange={() => {
        const obj = attachedObject
        updateObject(selectedId, {
          position: [obj.position.x, obj.position.y, obj.position.z],
          rotation: [obj.rotation.x, obj.rotation.y, obj.rotation.z],
          scale: [
            Math.max(0.01, obj.scale.x),
            Math.max(0.01, obj.scale.y),
            Math.max(0.01, obj.scale.z),
          ],
        })
      }}
      onMouseUp={() => {
        if (!dragging.current) return
        dragging.current = false
        const obj = attachedObject
        commitObjectUpdate(selectedId, {
          position: [obj.position.x, obj.position.y, obj.position.z],
          rotation: [obj.rotation.x, obj.rotation.y, obj.rotation.z],
          scale: [
            Math.max(0.01, obj.scale.x),
            Math.max(0.01, obj.scale.y),
            Math.max(0.01, obj.scale.z),
          ],
        })
        // 恢复 R3F 合成事件
        events.enabled = prevEventsEnabled.current
      }}
    />
  )
}
