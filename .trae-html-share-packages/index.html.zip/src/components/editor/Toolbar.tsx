import { useRef, useState } from 'react'
import type { ComponentType, SVGProps } from 'react'
import {
  Palette,
  Move3D,
  RotateCcw,
  Maximize2,
  Undo2,
  Redo2,
  Trash2,
  File,
  Upload,
  Download,
} from 'lucide-react'
import { useEditorStore } from '@/store/editor'
import { toast } from '@/components/ui/Toast'
import type { PrimitiveType, SceneObject, TransformMode } from '@/types/editor'

type LucideIcon = ComponentType<SVGProps<SVGSVGElement> & { size?: number; strokeWidth?: number }>

const MODES: {
  value: TransformMode
  label: string
  hotkey: string
  Icon: LucideIcon
}[] = [
  { value: 'translate', label: '平移(W)', hotkey: 'W', Icon: Move3D },
  { value: 'rotate', label: '旋转(E)', hotkey: 'E', Icon: RotateCcw },
  { value: 'scale', label: '缩放(R)', hotkey: 'R', Icon: Maximize2 },
]

export function Toolbar() {
  const mode = useEditorStore((s) => s.transformMode)
  const setTransformMode = useEditorStore((s) => s.setTransformMode)
  const undo = useEditorStore((s) => s.undo)
  const redo = useEditorStore((s) => s.redo)
  const clearScene = useEditorStore((s) => s.clearScene)
  const undoAvailable = useEditorStore((s) => s.historyIndex > 0)
  const redoAvailable = useEditorStore((s) => s.historyIndex < s.history.length - 1)

  return (
    <header className="toolbar">
      <div className="toolbar-left">
        <div className="toolbar-brand">
          <Palette size={18} strokeWidth={2} />
          <span>3D 编辑器</span>
        </div>
      </div>

      <div className="toolbar-center">
        <div className="mode-group">
          {MODES.map((m) => {
            const Icon = m.Icon
            return (
              <button
                key={m.value}
                className={`mode-btn ${mode === m.value ? 'active' : ''}`}
                onClick={() => setTransformMode(m.value)}
                title={`${m.label}模式 · 热键 ${m.hotkey}`}
              >
                <Icon size={16} strokeWidth={2} className="mode-icon" />
                <span className="mode-label">{m.label}</span>
              </button>
            )
          })}
        </div>
      </div>

      <div className="toolbar-right">
        <button
          className="toolbar-btn"
          onClick={undo}
          disabled={!undoAvailable}
          title="撤销 (Ctrl+Z)"
        >
          <Undo2 size={14} strokeWidth={2} />
          <span>撤销</span>
        </button>
        <button
          className="toolbar-btn"
          onClick={redo}
          disabled={!redoAvailable}
          title="重做 (Ctrl+Y)"
        >
          <Redo2 size={14} strokeWidth={2} />
          <span>重做</span>
        </button>

        <div className="toolbar-divider" />

        <OpenSaveMenu />

        <div className="toolbar-divider" />

        <button
          className="toolbar-btn danger"
          onClick={() => {
            if (confirm('确定要清空整个场景吗？此操作可通过撤销恢复。')) {
              clearScene()
            }
          }}
          title="清空场景"
        >
          <Trash2 size={14} strokeWidth={2} />
          <span>清空</span>
        </button>
      </div>
    </header>
  )
}

/* ==================== 打开/保存菜单 ==================== */

function OpenSaveMenu() {
  const [open, setOpen] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  return (
    <div className="menu-wrapper">
      <button
        className="toolbar-btn"
        onClick={() => setOpen((v) => !v)}
        onBlur={() => setTimeout(() => setOpen(false), 120)}
      >
        <File size={14} strokeWidth={2} />
        <span>文件</span>
      </button>

      {open && (
        <div className="toolbar-menu" role="menu">
          <button
            onMouseDown={(e) => {
              e.preventDefault()
              setOpen(false)
              fileInputRef.current?.click()
            }}
          >
            <Upload size={14} strokeWidth={2} />
            <span>导入 JSON…</span>
          </button>
          <button
            onMouseDown={(e) => {
              e.preventDefault()
              setOpen(false)
              doExport()
            }}
          >
            <Download size={14} strokeWidth={2} />
            <span>导出 JSON…</span>
          </button>
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept=".json,application/json"
        style={{ display: 'none' }}
        onChange={(e) => {
          const f = e.target.files?.[0]
          if (!f) return
          handleImport(f)
          e.target.value = '' // 允许重选同一文件
        }}
      />
    </div>
  )
}

/* ==================== JSON schema ==================== */

const SCENE_SCHEMA_VERSION = '1.0'

interface ExportableScene {
  version: string
  objects: SceneObject[]
  environment: { sky: string; grid: boolean; shadow: boolean }
}

/** 深拷贝 objects 并生成可导出的 payload */
function buildExportPayload(): ExportableScene {
  const objects = useEditorStore.getState().objects.map((o) => ({
    ...o,
    position: [...o.position] as Vector3Tuple,
    rotation: [...o.rotation] as Vector3Tuple,
    scale: [...o.scale] as Vector3Tuple,
  }))
  return {
    version: SCENE_SCHEMA_VERSION,
    objects,
    environment: { sky: 'day', grid: true, shadow: true },
  }
}

/** 校验导入 JSON 是否符合 schema，返回合法对象数组或 null */
function validateAndExtract(raw: unknown): SceneObject[] | null {
  if (!raw || typeof raw !== 'object') return null
  const obj = raw as Record<string, unknown>
  if (obj.version !== SCENE_SCHEMA_VERSION && typeof obj.version !== 'string') return null
  const list = obj.objects
  if (!Array.isArray(list)) return null

  for (const item of list) {
    if (!item || typeof item !== 'object') return null
    const o = item as Record<string, unknown>
    if (typeof o.id !== 'string') return null
    if (typeof o.name !== 'string') return null
    if (!isPrimitiveType(o.type)) return null
    if (!isVec3Tuple(o.position)) return null
    if (!isVec3Tuple(o.rotation)) return null
    if (!isVec3Tuple(o.scale)) return null
    if (typeof o.color !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(o.color as string)) return null
    if (typeof o.visible !== 'boolean') return null
  }
  return list as SceneObject[]
}

function isVec3Tuple(v: unknown): v is [number, number, number] {
  return (
    Array.isArray(v) &&
    v.length === 3 &&
    (v as unknown[]).every((n) => typeof n === 'number' && Number.isFinite(n))
  )
}

function isPrimitiveType(t: unknown): t is PrimitiveType {
  return (
    t === 'box' ||
    t === 'sphere' ||
    t === 'cylinder' ||
    t === 'cone' ||
    t === 'torus' ||
    t === 'tetrahedron' ||
    t === 'plane'
  )
}

type Vector3Tuple = [number, number, number]

/* ==================== 导入 / 导出实现 ==================== */

function doExport() {
  const payload = buildExportPayload()
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `scene-${new Date().toISOString().replace(/[:.]/g, '-')}.json`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

async function handleImport(file: File) {
  const text = await file.text()
  let parsed: unknown
  try {
    parsed = JSON.parse(text)
  } catch {
    toast.error('文件不是有效的 JSON')
    return
  }
  const objects = validateAndExtract(parsed)
  if (!objects) {
    toast.error('文件格式不正确或版本不匹配')
    return
  }
  if (!confirm('导入将替换当前未保存的场景，继续？')) return
  useEditorStore.getState().replaceScene(objects)
}
