import * as THREE from 'three'
import { useRef } from 'react'

/** 全局注册表，存储 scene object id -> THREE.Mesh 引用 */
const registry = new Map<string, THREE.Object3D>()

export function registerMesh(id: string, mesh: THREE.Object3D | null) {
  if (mesh) registry.set(id, mesh)
  else registry.delete(id)
}

export function getMesh(id: string): THREE.Object3D | undefined {
  return registry.get(id)
}

export function useMeshRegistry() {
  const ref = useRef<THREE.Object3D | null>(null)
  const setRef = (id: string) => (node: THREE.Object3D | null) => {
    registerMesh(id, node)
    ref.current = node
  }
  return { ref, setRef }
}
