import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import type { PrimitiveType } from '@/types/editor'
import { useEditorStore } from '@/store/editor'
import { registerMesh } from './meshRegistry'
import * as THREE from 'three'

interface Props {
  id: string
  type: PrimitiveType
  color: string
  selected: boolean
  onClick: (id: string) => void
}

/** 根据类型渲染对应几何体，点击时通知外层选中 */
export function SceneMesh({ id, type, color, selected, onClick }: Props) {
  const meshRef = useRef<THREE.Mesh>(null)
  const position = useEditorStore((s) => {
    const o = s.objects.find((x) => x.id === id)
    return (o?.position ?? [0, 0, 0]) as [number, number, number]
  })
  const rotation = useEditorStore((s) => {
    const o = s.objects.find((x) => x.id === id)
    return (o?.rotation ?? [0, 0, 0]) as [number, number, number]
  })
  const scale = useEditorStore((s) => {
    const o = s.objects.find((x) => x.id === id)
    return (o?.scale ?? [1, 1, 1]) as [number, number, number]
  })

  // 注册 mesh 引用到全局 registry
  useEffect(() => {
    registerMesh(id, meshRef.current)
    return () => registerMesh(id, null)
  }, [id])

  // 选中时脉冲发光
  useFrame((state) => {
    if (!meshRef.current) return
    const mat = meshRef.current.material as THREE.MeshStandardMaterial
    if (selected) {
      mat.emissive.set('#ffffff')
      mat.emissiveIntensity = 0.1 + Math.sin(state.clock.elapsedTime * 4) * 0.08
    } else if (mat.emissiveIntensity > 0) {
      mat.emissive.set('#000000')
      mat.emissiveIntensity = 0
    }
  })

  const geometry = useMemo(() => createGeometry(type), [type])

  return (
    <mesh
      ref={meshRef}
      castShadow
      receiveShadow
      position={position}
      rotation={rotation}
      scale={scale}
      onClick={(e) => {
        e.stopPropagation()
        onClick(id)
      }}
    >
      <primitive object={geometry} attach="geometry" />
      <meshStandardMaterial color={color} roughness={0.5} metalness={0.1} />
    </mesh>
  )
}

function createGeometry(type: PrimitiveType): THREE.BufferGeometry {
  switch (type) {
    case 'box':
      return new THREE.BoxGeometry(1, 1, 1)
    case 'sphere':
      return new THREE.SphereGeometry(0.5, 32, 32)
    case 'cylinder':
      return new THREE.CylinderGeometry(0.5, 0.5, 1, 32)
    case 'cone':
      return new THREE.ConeGeometry(0.5, 1, 32)
    case 'torus':
      return new THREE.TorusGeometry(0.4, 0.15, 16, 48)
    case 'tetrahedron':
      return new THREE.TetrahedronGeometry(0.6)
    case 'plane':
      return new THREE.PlaneGeometry(1, 1)
    default:
      return new THREE.BoxGeometry(1, 1, 1)
  }
}
