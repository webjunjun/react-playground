import type { ComponentType } from 'react'
import type { SVGProps } from 'react'
import {
  Box,
  Circle,
  Cylinder,
  Triangle,
  CircleDot,
  Diamond,
  Square,
} from 'lucide-react'
import type { PrimitiveType } from '@/types/editor'

type LucideIcon = ComponentType<SVGProps<SVGSVGElement> & { size?: number; strokeWidth?: number }>

export interface PrimitivePreset {
  type: PrimitiveType
  label: string
  Icon: LucideIcon
}

export const PRIMITIVE_PRESETS: PrimitivePreset[] = [
  { type: 'box', label: '长方体', Icon: Box },
  { type: 'sphere', label: '球体', Icon: Circle },
  { type: 'cylinder', label: '圆柱', Icon: Cylinder },
  { type: 'cone', label: '圆锥', Icon: Triangle },
  { type: 'torus', label: '圆环', Icon: CircleDot },
  { type: 'tetrahedron', label: '四面体', Icon: Diamond },
  { type: 'plane', label: '平面', Icon: Square },
]
