import { useRef } from 'react'
import { useEditorStore } from '@/store/editor'
import type { Vector3Tuple } from 'three'

export function PropertiesPanel() {
  const selectedId = useEditorStore((s) => s.selectedId)
  const obj = useEditorStore((s) => s.objects.find((o) => o.id === selectedId))
  const updateObject = useEditorStore((s) => s.updateObject)
  const commitObjectUpdate = useEditorStore((s) => s.commitObjectUpdate)
  const toggleVisible = useEditorStore((s) => s.toggleVisible)

  if (!obj) {
    return (
      <aside className="properties-panel">
        <div className="empty-hint">选中对象以编辑属性</div>
      </aside>
    )
  }

  return (
    <aside className="properties-panel">
      <h3 className="panel-title">{obj.name}</h3>

      {/* 名称 */}
      <Field label="名称">
        <input
          type="text"
          value={obj.name}
          maxLength={64}
          onChange={(e) => updateObject(obj.id, { name: e.target.value })}
          onBlur={() => commitObjectUpdate(obj.id, { name: obj.name })}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              ;(e.target as HTMLInputElement).blur()
            }
          }}
        />
      </Field>

      {/* 颜色 */}
      <Field label="颜色">
        <input
          type="color"
          value={obj.color}
          onChange={(e) => commitObjectUpdate(obj.id, { color: e.target.value })}
        />
      </Field>

      {/* 位置 */}
      <Vector3Field
        label="位置"
        values={obj.position}
        step={0.01}
        onLiveChange={(v) => updateObject(obj.id, { position: v })}
        onCommit={(v) => commitObjectUpdate(obj.id, { position: v })}
      />

      {/* 旋转 */}
      <Vector3Field
        label="旋转 (弧度)"
        values={obj.rotation}
        step={0.01}
        onLiveChange={(v) => updateObject(obj.id, { rotation: v })}
        onCommit={(v) => commitObjectUpdate(obj.id, { rotation: v })}
      />

      {/* 缩放 */}
      <Vector3Field
        label="缩放"
        values={obj.scale}
        step={0.1}
        min={0.01}
        onLiveChange={(v) => updateObject(obj.id, { scale: v })}
        onCommit={(v) => commitObjectUpdate(obj.id, { scale: v })}
      />

      {/* 可见 */}
      <Field label="可见">
        <label className="checkbox-row">
          <input
            type="checkbox"
            checked={obj.visible}
            onChange={() => toggleVisible(obj.id)}
          />
          <span>{obj.visible ? '渲染中' : '已隐藏'}</span>
        </label>
      </Field>
    </aside>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="prop-field">
      <label>{label}</label>
      <div className="prop-input">{children}</div>
    </div>
  )
}

interface Vector3FieldProps {
  label: string
  values: Vector3Tuple
  step?: number
  min?: number
  onLiveChange: (v: Vector3Tuple) => void
  onCommit: (v: Vector3Tuple) => void
}

function Vector3Field({
  label,
  values,
  step = 0.01,
  min,
  onLiveChange,
  onCommit,
}: Vector3FieldProps) {
  const axes: ('X' | 'Y' | 'Z')[] = ['X', 'Y', 'Z']
  const colors = ['#ef4444', '#22c55e', '#3b82f6']
  // 用 ref 存最后一次 committed 的值，避免 blur 时 commit 相同值产生冗余历史
  const committedRef = useRef(values)

  const handleChange = (i: number, raw: string) => {
    let v = Number(raw)
    if (!Number.isFinite(v)) return
    if (min !== undefined && v < min) v = min
    const next = [...values] as Vector3Tuple
    next[i] = v
    onLiveChange(next)
  }

  const handleCommit = () => {
    // 只在值确实变了才 commit
    if (
      committedRef.current[0] !== values[0] ||
      committedRef.current[1] !== values[1] ||
      committedRef.current[2] !== values[2]
    ) {
      committedRef.current = values
      onCommit(values)
    }
  }

  return (
    <div className="prop-field">
      <label>{label}</label>
      <div className="vec3-row">
        {axes.map((axis, i) => (
          <div key={axis} className="vec3-input">
            <span className="vec3-axis" style={{ color: colors[i] }}>
              {axis}
            </span>
            <input
              type="number"
              step={step}
              min={min}
              value={Number(values[i].toFixed(4))}
              onChange={(e) => handleChange(i, e.target.value)}
              onBlur={handleCommit}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  ;(e.target as HTMLInputElement).blur()
                }
              }}
            />
          </div>
        ))}
      </div>
    </div>
  )
}
