import { useState } from 'react'
import { Copy, X } from 'lucide-react'
import { useEditorStore } from '@/store/editor'
import { PRIMITIVE_PRESETS } from './presets'

export function Sidebar() {
  const [tab, setTab] = useState<'library' | 'objects'>('library')
  const objectCount = useEditorStore((s) => s.objects.length)

  return (
    <aside className="sidebar">
      <div className="sidebar-tabs">
        <button
          className={`sidebar-tab ${tab === 'library' ? 'active' : ''}`}
          onClick={() => setTab('library')}
        >
          资源库
        </button>
        <button
          className={`sidebar-tab ${tab === 'objects' ? 'active' : ''}`}
          onClick={() => setTab('objects')}
        >
          场景 ({objectCount})
        </button>
      </div>

      <div className="sidebar-content">
        {tab === 'library' ? <LibraryPanel /> : <ObjectList />}
      </div>
    </aside>
  )
}

function LibraryPanel() {
  const addObject = useEditorStore((s) => s.addObject)

  return (
    <div className="library-grid">
      {PRIMITIVE_PRESETS.map((p) => {
        const Icon = p.Icon
        return (
          <button
            key={p.type}
            className="library-item"
            onClick={() => addObject(p.type)}
            title={`添加${p.label}`}
          >
            <Icon size={26} strokeWidth={1.8} className="library-icon" />
            <span className="library-label">{p.label}</span>
          </button>
        )
      })}
    </div>
  )
}

function ObjectList() {
  const objects = useEditorStore((s) => s.objects)
  const selectedId = useEditorStore((s) => s.selectedId)
  const selectObject = useEditorStore((s) => s.selectObject)
  const removeObject = useEditorStore((s) => s.removeObject)
  const duplicateObject = useEditorStore((s) => s.duplicateObject)
  const toggleVisible = useEditorStore((s) => s.toggleVisible)

  if (objects.length === 0) {
    return <div className="empty-hint">场景为空，从「资源库」添加对象</div>
  }

  return (
    <ul className="object-list">
      {objects.map((o) => (
        <li
          key={o.id}
          className={`object-item ${selectedId === o.id ? 'selected' : ''}`}
          onClick={() => selectObject(o.id)}
        >
          <label className="object-visibility" onClick={(e) => e.stopPropagation()}>
            <input
              type="checkbox"
              checked={o.visible}
              onChange={() => toggleVisible(o.id)}
            />
            <span className="color-dot" style={{ background: o.color }} />
          </label>

          <span className="object-name">{o.name}</span>

          <div className="object-actions" onClick={(e) => e.stopPropagation()}>
            <button
              title="复制"
              onClick={() => duplicateObject(o.id)}
              className="icon-btn"
            >
              <Copy size={13} strokeWidth={2} />
            </button>
            <button
              title="删除"
              onClick={() => removeObject(o.id)}
              className="icon-btn danger"
            >
              <X size={13} strokeWidth={2.5} />
            </button>
          </div>
        </li>
      ))}
    </ul>
  )
}
